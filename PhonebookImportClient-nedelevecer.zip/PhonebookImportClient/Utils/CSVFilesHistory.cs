﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhonebookImportClient.Utils
{
    public class CSVFilesHistoryItem
    {
        public string FileName { get; set; }
        public string HashCode { get; set; }
        public bool HasHeader { get; set; }
        public int EncodingCP { get; set; }
        public int NameColumnIndex { get; set; }
        public int NumberColumnIndex { get; set; }
    }

    class CSVFilesHistory
    {
        public List<CSVFilesHistoryItem> Items { get; set; }
        private string cfgFilePathName;
        //private string csvFilePathName;

        public CSVFilesHistory()
        {
            cfgFilePathName = Path.Combine(
                Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location),
                String.IsNullOrEmpty(Properties.Settings.Default.ConfigFileName) ?
                    "csvfileshistory.cfg" : Properties.Settings.Default.ConfigFileName);
            ReadAllHistory();
        }

        private void ReadAllHistory()
        {
            Items = new List<CSVFilesHistoryItem>();
            if (File.Exists(cfgFilePathName))
            {
                string[] cfgItems = File.ReadAllLines(cfgFilePathName);
                for (int i = 0; i < cfgItems.Length; i++)
                {
                    string[] cfgItem = cfgItems[i].Split(new char[] { ';' });
                    try
                    {
                        CSVFilesHistoryItem historyItem = new CSVFilesHistoryItem();
                        historyItem.FileName = cfgItem[0];
                        historyItem.HashCode = cfgItem[1];
                        historyItem.HasHeader = (cfgItem[2] == true.ToString());
                        historyItem.NameColumnIndex = int.Parse(cfgItem[3]);
                        historyItem.NumberColumnIndex = int.Parse(cfgItem[4]);
                        historyItem.EncodingCP = int.Parse(cfgItem[5]);
                        Items.Add(historyItem);
                    }
                    catch { }
                }
            }
        }

        public CSVFilesHistoryItem GetItem(string fileHash)
        {
            if (!String.IsNullOrEmpty(fileHash))
            {
                foreach (CSVFilesHistoryItem item in Items)
                {
                    if (item.HashCode == fileHash)
                        return item;
                }
            }
            return null;
        }

        public void SaveNewSettings(CSVFilesHistoryItem newHistoryItem)
        {
            StringBuilder newConfig = new StringBuilder();
            newConfig.AppendFormat("{0};{1};{2};{3};{4};{5}",
                newHistoryItem.FileName,
                newHistoryItem.HashCode,
                newHistoryItem.HasHeader,
                newHistoryItem.NameColumnIndex,
                newHistoryItem.NumberColumnIndex,
                newHistoryItem.EncodingCP 
                );

            File.AppendAllText(cfgFilePathName, newConfig.ToString());
            Items.Add(newHistoryItem);
        }




    }
}

