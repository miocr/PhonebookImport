﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.ServiceModel;
using Microsoft.Win32;

using System.Threading.Tasks;

using PhonebookImportClient.Utils;
using PhonebookImportClient.ViewModels;
using PhonebookImportClient.Views;
using PhonebookImportClient.PhobeboookImportService;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Data;

namespace PhonebookImportClient.ViewModels
{

    public class MainViewModel : ViewModelBase
    {
        private PhonebookImportServiceClient service;

        private CSVFile csvFile;
        private CSVFilesHistory csvFilesHistory;

        private const char delimiter = ';';

        private DataTable _dataTable;
        private DataView _dataGridData;
        private string _responseMessage = String.Empty;
        private ObservableCollection<bool> _tabControlItemEnabled =
            new ObservableCollection<bool>(new[] { true, false, false });
        private int _tabControlSelectedIndex = 0;
        private List<string> _assignComboColumns;
        public int _assignedNameColumnIndex = -1;
        public int _assignedNumberColumnIndex = -1;
        private bool _btnImportEnabled = false;

        #region Parameters

        public bool CSVHasHeader { get; set; } = false;
        public bool CP1250 { get; set; } = true;
        public bool CP852 { get; set; } = false;

        public string ResponseMessage
        {
            get { return _responseMessage; }
            set
            {
                _responseMessage = value;
                NotifyPropertyChanged();
            }
        }

        public ObservableCollection<bool> TabControlItemEnabled
        {
            get { return _tabControlItemEnabled; }
            set
            {
                _tabControlItemEnabled = value;
                NotifyPropertyChanged();
            }
        }

        public int TabControlSelectedIndex
        {
            get { return _tabControlSelectedIndex; }
            set
            {
                _tabControlSelectedIndex = value;
                NotifyPropertyChanged();
            }
        }

        public bool BtnImportEnabled
        {
            get { return _btnImportEnabled; }
            set
            {
                _btnImportEnabled = value;
                NotifyPropertyChanged();
            }
        }

        public DataView DataGridData
        {
            get { return _dataGridData; }
            set
            {
                _dataGridData = value;
                NotifyPropertyChanged();
            }
        }

        public string Title
        {
            get { return "PhonebookImportClient"; }
        }

        //TODO
        public string Popis1
        {
            get { return "Popis 1"; }
        }


        public List<string> AssignComboColumns
        {
            get { return _assignComboColumns; }
            set
            {
                _assignComboColumns = value;
                NotifyPropertyChanged();
            }
        }

        public int AssignedNameColumnIndex
        {
            get { return _assignedNameColumnIndex; }
            set
            {
                _assignedNameColumnIndex = value;
                NotifyPropertyChanged();
                BtnImportEnabled = ValidateColumnsAssignment();
            }
        }

        public int AssignedNumberColumnIndex
        {
            get { return _assignedNumberColumnIndex; }
            set
            {
                _assignedNumberColumnIndex = value;
                NotifyPropertyChanged();
                BtnImportEnabled = ValidateColumnsAssignment();
            }
        }


        #endregion

        #region Constructors
        public MainViewModel()
        {
            service = new PhonebookImportServiceClient();
            csvFile = new CSVFile();
            csvFilesHistory = new CSVFilesHistory();
            TabControlSetStep(1);
        }

        #endregion

        #region Methods


        /// <summary>
        /// Výběr CSV souboru a jeho načtení do DataGrid
        /// </summary>
        private void OpenCSVFileAndReadData()
        {
            if (csvFile.Open())
            {
                csvFile.HasHeader = CSVHasHeader;
                csvFile.EncodingCP = CP1250 ? 1250 : 852;

                CSVFilesHistoryItem historyItem = null;
                if (csvFilesHistory.Items.Count > 0)
                {
                    historyItem = csvFilesHistory.GetItem(csvFile.HashCode);
                    if (historyItem != null)
                    {
                        // Pro Read CSV
                        csvFile.HasHeader = historyItem.HasHeader;
                        csvFile.EncodingCP = historyItem.EncodingCP;

                        // Pro UI Read CSV
                        CSVHasHeader = historyItem.HasHeader;
                        CP1250 = (historyItem.EncodingCP == 1250);
                        CP852 = (historyItem.EncodingCP == 852);
                    }
                }

                _dataTable = csvFile.Read();

                if (_dataTable != null)
                {
                    DataGridData = _dataTable.DefaultView;
                    FillAssignCombos();

                    if (historyItem != null)
                    {
                        //Pro UI Import CSV
                        AssignedNameColumnIndex = historyItem.NameColumnIndex;
                        AssignedNumberColumnIndex = historyItem.NumberColumnIndex;
                    }
                    else
                    {
                        AssignedNameColumnIndex = -1;
                        AssignedNumberColumnIndex = -1;
                    }

                    ImportDataCmd.CanExecute(true);
                    TabControlSetStep(2);
                }
            }
        }

        private void ImportDataAndSaveCfg()
        {
            ImportContacts();
            TabControlSetStep(3);
            CSVFilesHistoryItem historyItem = csvFilesHistory.GetItem(csvFile.HashCode);
            if (historyItem == null)
            {
                historyItem = new CSVFilesHistoryItem()
                {
                    FileName = Path.GetFileName(csvFile.FilePathName),
                    HashCode = csvFile.HashCode,
                    HasHeader = CSVHasHeader,
                    NameColumnIndex = AssignedNameColumnIndex,
                    NumberColumnIndex = AssignedNumberColumnIndex,
                    EncodingCP = CP1250 ? 1250 : 852
                };
                csvFilesHistory.SaveNewSettings(historyItem);
            }
            else
            {
                // TODO update
            }
        }

        private void FillAssignCombos()
        {
            if (AssignComboColumns == null)
                AssignComboColumns = new List<string>();
            else
                AssignComboColumns.Clear();

            foreach (DataColumn col in _dataTable.Columns)
                AssignComboColumns.Add((string)col.ColumnName);
        }

        private bool ValidateColumnsAssignment()
        {
            bool result = false;
            if (AssignedNameColumnIndex > -1 && AssignedNumberColumnIndex > -1)
            {
                if (AssignedNameColumnIndex == AssignedNumberColumnIndex)
                {
                    MessageBox.Show("Pro Jméno a Telefon nemůže být přiřazen stejný sloupec.\n" +
                        "Je potřeba vybrat jiný sloupec.", "Chyba přiřazení",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                    result = true;
            }
            return result;
        }

        private void TabControlSetStep(int step)
        {
            if (step >= 1 && step <= 3)
            {
                TabControlSelectedIndex = step - 1;
                for (int i = 0; i < TabControlItemEnabled.Count; i++)
                {
                    TabControlItemEnabled[i] = (i < (step));
                }
            }
        }

        private void ImportContacts()
        {
            int rowNumber = 1;
            List<PhonebookRecord> records = new List<PhonebookRecord>();
            ImportRecordsResponse response = null;
            StringBuilder responseMessageSB = new StringBuilder();

            foreach (DataRow row in _dataTable.Rows)
            {
                PhonebookRecord record = new PhonebookRecord()
                {
                    RecordId = rowNumber++,
                    Company = (string)row[AssignComboColumns[_assignedNameColumnIndex]],
                    Number = (string)row[AssignComboColumns[_assignedNumberColumnIndex]]
                };
                records.Add(record);
            }

            try
            {
                response = service.ImportContacts(records.ToArray());
                responseMessageSB.AppendFormat("Počet úspěšně importovaných záznamů: {0}",
                    response.SuccessRecordsCount);
            }
            catch (FaultException<ImportRecordsResponseError> ex)
            {

                responseMessageSB.AppendFormat
                    ("Počet úspěšně importovaných záznamů: {0}\n\n", ex.Detail.SuccessRecordsCount);
                responseMessageSB.AppendFormat
                    ("Počet záznamů, které se nepodařilo importovat: {0}\n\n", ex.Detail.ErrorRecordsCount);
                responseMessageSB.Append("Seznam chyb v importním souboru::\n");
                foreach (ImportRecordResponseError importError in ex.Detail.ImportErrors)
                {
                    responseMessageSB.AppendFormat(
                        "Řádek:{0}\t\tSloupec:{1}\t\tChyba:{2}\n",
                        importError.RecordId.Value.ToString("00"),
                        importError.ColumnId.Value.ToString("00"),
                        importError.ErrorType.ToString());
                }
            }
            catch (CommunicationException ex)
            {
                MessageBox.Show("Komunikace se službou se nezdařila! \n\n" + ex.Message, "Chyba komunikace",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba programu! \n\n" + ex.Message, "Chyba programu",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                ResponseMessage = responseMessageSB.ToString();
            }
        }


        private void ExitApp()
        {
            Application.Current.MainWindow.Close();
        }

        #endregion

        #region Commands
        private bool AlwaysTrue() { return true; }
        private bool AlwaysFalse() { return false; }

        public ICommand OpenCSVFileCmd { get { return new RelayCommand(OpenCSVFileAndReadData, AlwaysTrue); } }
        public ICommand ImportDataCmd { get { return new RelayCommand(ImportDataAndSaveCfg); } }
        public ICommand ExitAppCmd { get { return new RelayCommand(ExitApp); } }
    }

    #endregion

    #region Events
    #endregion


}
