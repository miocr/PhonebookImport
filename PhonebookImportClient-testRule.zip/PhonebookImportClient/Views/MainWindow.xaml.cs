﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using System.ServiceModel;
using PhonebookImportClient.PhobeboookImportService;
using System.Data;
using System.Linq;
using System.Windows.Input;

using PhonebookImportClient.Utils;
using PhonebookImportClient.ViewModels;
using PhonebookImportClient.Views;


namespace PhonebookImportClient.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        

        private MainViewModel mvm;

        public MainWindow()
        {
            InitializeComponent();
            //service = new PhonebookImportServiceClient();
            tabControl.SelectedIndex = 0;
        }

        public MainWindow(MainViewModel dataContext)
        {
            this.DataContext = dataContext;
            InitializeComponent();
            tabControl.SelectedIndex = 0;

            mvm = dataContext;
        }

        private void btnOpenFile_Click(object sender, RoutedEventArgs e)
        {

            return;
            //mvm = this.DataContext as MainViewModel;
            try
            {

                //mvm.CSVDataTable = mvm.LoadCSVFile();
                // dataGrid.DataContext = mvm.CSVDataTable.DefaultView;
                //comboBoxNameAssign.DataContext = AssignComboValues;
                //mvm.SetAssignCombos();
                tabItem2.IsEnabled = true;
                tabControl.SelectedIndex = 1;
            }
            catch (Exception ex)
            {
                // TODO
                //HandleExpception(ex);
            }

            /*
            PhonebookRecord record = new PhonebookRecord()
            {
                Company = "ZZZZ",
                Number = "8989898",
                Description = "SWSASA"
            };

            try
            {
                ImportRecordResponse response = service.ImportContact(record);
            }
            catch (FaultException<ImportRecordResponseError> ex)
            {
                MessageBox.Show("Komunikace se službou se nezdařila! \n\n" + ex.Detail.Description, "Chyba importu",
                    MessageBoxButton.OK, MessageBoxImage.Error);

            }
            catch (CommunicationException ex)
            {
                MessageBox.Show("Komunikace se službou se nezdařila! \n\n" + ex.Message, "Chyba komunikace",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba programu! \n\n" + ex.Message, "Chyba programu",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            */
        }

        //private void ImportContacts()
        //{

        //    List<PhonebookRecord> records = new List<PhonebookRecord>();
        //    string nameColumnName = (string)comboBoxNameAssign.SelectedItem;
        //    string numberColumnName = (string)comboBoxNumberAssign.SelectedItem;

        //    int rowNumber = 1;
        //    foreach (DataRow row in mvm.CSVDataTable.Rows)
        //    {
        //        PhonebookRecord record = new PhonebookRecord()
        //        {
        //            RecordId = rowNumber++,
        //            Company = (string)row[nameColumnName],
        //            Number = (string)row[numberColumnName]
        //        };
        //        records.Add(record);
        //    }

        //    ImportRecordsResponse response = null;
        //    StringBuilder responseMessage = new StringBuilder();
        //    try
        //    {
        //        response = service.ImportContacts(records.ToArray());
        //        responseMessage.AppendFormat("Počet úspěšně importovaných záznamů: {0}",
        //            response.SuccessRecordsCount);
        //    }
        //    catch (FaultException<ImportRecordsResponseError> ex)
        //    {

        //        responseMessage.AppendFormat
        //            ("Počet úspěšně importovaných záznamů: {0}\n\n", ex.Detail.SuccessRecordsCount);
        //        responseMessage.AppendFormat
        //            ("Počet záznamů, které se nepodařilo importovat: {0}\n\n", ex.Detail.ErrorRecordsCount);
        //        responseMessage.Append("Seznam chyb v importním souboru::\n");
        //        foreach (ImportRecordResponseError importError in ex.Detail.ImportErrors)
        //        {
        //            responseMessage.AppendFormat(
        //                "Řádek:{0}\t\tSloupec:{1}\t\tChyba:{2}\n",
        //                importError.RecordId.Value.ToString("00"),
        //                importError.ColumnId.Value.ToString("00"),
        //                importError.ErrorType.ToString());
        //        }
        //    }
        //    catch (CommunicationException ex)
        //    {
        //        MessageBox.Show("Komunikace se službou se nezdařila! \n\n" + ex.Message, "Chyba komunikace",
        //            MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Chyba programu! \n\n" + ex.Message, "Chyba programu",
        //            MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //    finally
        //    {
        //        tabItem3.IsEnabled = true;
        //        tabControl.SelectedIndex = 2;
        //        textBoxResponse.Text = responseMessage.ToString();
        //    }
        //}

        private void SaveImportFileSettings()
        {

            // TODO
            //var checkedButton = radioCP.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked);

            //// zakladni file hash (lze ale i jinak...)
            //FileInfo fi = new FileInfo(csvFilePath);
            //int fhash = string.Concat(fi.Name, fi.LastWriteTime.ToUniversalTime(),
            //    fi.CreationTime.ToUniversalTime(), fi.Length.ToString()).GetHashCode();

            //List<string> savedCfgs = new List<string>();
            //if (File.Exists(cfgFilePath))
            //{
            //    string[] cfgItems = File.ReadAllLines(cfgFilePath);
            //    for (int i = 0; i < cfgItems.Length; i++)
            //    {
            //        savedCfgs.Add((string)cfgItems[i].Split(delimiter).GetValue(0));
            //    }
            //}

            //if (!savedCfgs.Contains(fhash.ToString()))
            //{

            //    StringBuilder newConfig = new StringBuilder();
            //    File.AppendAllText(cfgFilePath, newConfig.ToString
            //     TODO
            //    newConfig.AppendFormat("{0};{1};{2};{3};{4}", fhash.ToString(),
            //        comboBoxNameAssign.SelectedIndex, comboBoxNumberAssign.SelectedIndex,
            //        checkBox1LineHeader.IsChecked.ToString(), radioCP.Content);
            //    File.AppendAllText(cfgFilePath, newConfig.ToString());
            //}
        }

        //TODO to model
        private void tabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            return;
            TabControl tabControl = sender as TabControl;
            if (tabControl != null && tabControl.Items.Count == 3)
            {
                if (tabControl.SelectedIndex == 0)
                {
                    (tabControl.Items[1] as TabItem).IsEnabled = false;
                    (tabControl.Items[2] as TabItem).IsEnabled = false;
                }
                else if (tabControl.SelectedIndex == 1)
                {
                    (tabControl.Items[2] as TabItem).IsEnabled = false;
                }
            }
        }

        private void comboBoxAssign_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            return;
            if (comboBoxNameAssign.SelectedIndex > -1 && comboBoxNumberAssign.SelectedIndex > -1)
                btnImport.IsEnabled = true;
        }

        private void btnImport_Click(object sender, RoutedEventArgs e)
        {
            return;
            SaveImportFileSettings();
            //ImportContacts();
        }

        private void comboBoxNameAssign_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
