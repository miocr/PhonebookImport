﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.ServiceModel;
using Microsoft.Win32;

using System.Threading.Tasks;

using PhonebookImportClient.Utils;
using PhonebookImportClient.ViewModels;
using PhonebookImportClient.Views;
using PhonebookImportClient.PhobeboookImportService;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Data;

namespace PhonebookImportClient.ViewModels
{

    public class SecondAssignedColumnWrapper : DependencyObject    
    {
        public static readonly DependencyProperty SeccondAssignedColumnIndexProperty =
           DependencyProperty.Register("SecondAssignedColumnIndex", 
               typeof(int), typeof(SecondAssignedColumnWrapper));

        public int SecondAssignedColumnIndex
        {
            get { return (int)GetValue(SeccondAssignedColumnIndexProperty); }
            set { SetValue(SeccondAssignedColumnIndexProperty, value); }
        }
    }

    public class ColumnAssignmentRule : ValidationRule
    {
        public SecondAssignedColumnWrapper SecondAssignedColumnWrapper { get; set; }

        public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
        {
            int x = this.SecondAssignedColumnWrapper.SecondAssignedColumnIndex;
            return ValidationResult.ValidResult;
        }
    }

    public class MainViewModel : ViewModelBase
    {
        private PhonebookImportServiceClient service;

        private const int maxCSVColumns = 20;
        private const char delimiter = ';';
        private const string cfgFileName = "import.cfg";

        private string cfgFilePathName;
        private string csvFilePathName;
        private DataTable csvDataTable;
        private DataView _dataGridData;
        private string _responseMessage = String.Empty;
        private ObservableCollection<bool> _tabControlItemEnabled =
            new ObservableCollection<bool>(new[] { true, false, false });
        private int _tabControlSelectedIndex = 0;
        private List<string> _assignComboColumns;
        public int _assignedNameColumnIndex { get; set; } = -1;
        public int _assignedNumberColumnIndex { get; set; } = -1;


        private bool _btnImportEnabled = false;



        #region Parameters

        public bool CSVHasHeader { get; set; } = false;
        public bool CP1250 { get; set; } = true;
        public bool CP852 { get; set; } = false;
        public string AssignedNameColumnText = null;
        public string AssignedNumberColumnText = null;

        public string ResponseMessage
        {
            get { return _responseMessage; }
            set
            {
                _responseMessage = value;
                NotifyPropertyChanged();
            }
        }

        public ObservableCollection<bool> TabControlItemEnabled
        {
            get { return _tabControlItemEnabled; }
            set
            {
                _tabControlItemEnabled = value;
                NotifyPropertyChanged();
            }
        }

        public int TabControlSelectedIndex
        {
            get { return _tabControlSelectedIndex; }
            set
            {
                _tabControlSelectedIndex = value;
                NotifyPropertyChanged();
            }
        }

        public bool BtnImportEnabled
        {
            get { return _btnImportEnabled; }
            set
            {
                _btnImportEnabled = value;
                NotifyPropertyChanged();
            }
        }

        public DataView DataGridData
        {
            get { return _dataGridData; }
            set
            {
                _dataGridData = value;
                NotifyPropertyChanged();
            }
        }

        public string Title
        {
            get { return "PhonebookImportClient"; }
        }

        //TODO
        public string Popis1
        {
            get { return "Popis 1"; }
        }


        public List<string> AssignComboColumns
        {
            get { return _assignComboColumns; }
            set
            {
                _assignComboColumns = value;
                NotifyPropertyChanged();
            }
        }

        public int AssignedNameColumnIndex
        {
            get { return _assignedNameColumnIndex; }
            set
            {
                _assignedNameColumnIndex = value;
                //if (!ValidateColumnAssignment())
                //{
                //    _assignedNameColumnIndex = -1;
                //    AssignedNameColumnText = null;
                //}
                NotifyPropertyChanged();
            }
        }

        public int AssignedNumberColumnIndex
        {
            get { return _assignedNumberColumnIndex; }
            set
            {
                _assignedNumberColumnIndex = value;
                //if (!ValidateColumnAssignment())
                //{
                //    _assignedNumberColumnIndex = -1;
                //    AssignedNumberColumnText = null;
                //}
                NotifyPropertyChanged();

            }
        }


        #endregion

        #region Constructors
        public MainViewModel()
        {
            TabControlSetStep(1);
            cfgFilePathName = Path.Combine(System.Reflection.Assembly.GetEntryAssembly().Location, cfgFileName);
            service = new PhonebookImportServiceClient();
        }

        #endregion

        #region Methods

        public void FillAssignCombos()
        {
            if (AssignComboColumns == null)
                AssignComboColumns = new List<string>();
            else
                AssignComboColumns.Clear();

            foreach (DataColumn col in csvDataTable.Columns)
                AssignComboColumns.Add((string)col.ColumnName);
        }

        /// <summary>
        /// Výběr CSV souboru a jeho načtení do DataGrid
        /// </summary>

        private void OpenCSVFileAndReadData()
        {
            LoadCSVFile();
            FillAssignCombos();
            ImportDataCmd.CanExecute(true);
            TabControlSetStep(2);

        }

        private void ImportDataAndSaveCfg()
        {
            ImportContacts();
            TabControlSetStep(3);
            //SaveImportFileSettings();
        }

        private bool ValidateColumnAssignment()
        {
            bool result = true;
            if (AssignedNameColumnIndex > -1 && AssignedNumberColumnIndex > -1)
            {
                if (AssignedNameColumnIndex == AssignedNumberColumnIndex)
                {
                    MessageBox.Show("Pro Jméno a Telefon nemůže být přiřazen stejný sloupec.\n" +
                        "Je potřeba nastavit jiný sloupec.", "Chyba přiřazení",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    result = false;
                }
                BtnImportEnabled = result;
            }
            return result;
        }

        private void TabControlSetStep(int step)
        {
            if (step >= 1 && step <= 3)
            {
                TabControlSelectedIndex = step - 1;
                for (int i = 0; i < TabControlItemEnabled.Count; i++)
                {
                    TabControlItemEnabled[i] = (i < (step));
                }

                //TabControlIndex = step - 1;
                //switch (step)
                //{
                //    case 1:
                //        TabIndex1Enabled = true;
                //        TabIndex2Enabled = false;
                //        TabIndex3Enabled = false;
                //        break;
                //    case 2:
                //        TabIndex1Enabled = true;
                //        TabIndex2Enabled = true;
                //        TabIndex3Enabled = false;
                //        break;
                //    case 3:
                //        TabIndex1Enabled = true;
                //        TabIndex2Enabled = true;
                //        TabIndex3Enabled = true;
                //        break;
                //}
            }
        }

        private void LoadCSVFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = ".csv";
            openFileDialog.Filter = "CSV soubory (.csv)|*.csv";
            openFileDialog.Title = "Výběr souboru pro import";

            //if (openFileDialog.ShowDialog() == true) csvFilePath = openFileDialog.FileName;
            csvFilePathName = @"..\..\..\Src1.csv";

            DataSet dataSet = new DataSet();
            dataSet.Tables.Add("Import");
            csvDataTable = dataSet.Tables["Import"];

            Encoding csvEncoding = Encoding.GetEncoding(1250);
            if (CP852)
                csvEncoding = Encoding.GetEncoding(852);

            string[] csvLines = { };
            try
            {
                csvLines = File.ReadAllLines(csvFilePathName, csvEncoding);
            }
            catch (Exception)
            {
                //TODO HandleException
            }

            int columnsCount = 0;
            string[] rowValues;
            DataRow dataRow = null;
            if (csvLines.Length > 0)
            {
                rowValues = csvLines[0].Split(delimiter);
                columnsCount = (rowValues.Length > maxCSVColumns) ? maxCSVColumns : rowValues.Length;
                if (columnsCount > 0)
                {
                    //Header
                    for (int i = 0; i < rowValues.Length; i++)
                    {
                        DataColumn col = new DataColumn();
                        col.MaxLength = 200;
                        col.DataType = typeof(string);
                        if (CSVHasHeader)
                            col.ColumnName = rowValues[i];
                        else
                            col.ColumnName = String.Format("Sloupec {0}", i + 1);
                        csvDataTable.Columns.Add(col);
                    }

                    //Data
                    for (int row = CSVHasHeader ? 1 : 0; row < csvLines.Length; row++)
                    {
                        dataRow = csvDataTable.NewRow();
                        rowValues = csvLines[row].Split(delimiter);
                        // jen validni radky (pocet sloupcu radku odpovida prvnimu radku)
                        if (rowValues.Length == columnsCount)
                        {
                            for (int col = 0; col < columnsCount; col++)
                                dataRow[col] = Convert.ToString(rowValues[col]);
                        }
                        csvDataTable.Rows.Add(dataRow);
                    }
                }
            }
            DataGridData = csvDataTable.DefaultView;
        }

        private void ImportContacts()
        {
            int rowNumber = 1;
            List<PhonebookRecord> records = new List<PhonebookRecord>();
            ImportRecordsResponse response = null;
            StringBuilder responseMessageSB = new StringBuilder();

            foreach (DataRow row in csvDataTable.Rows)
            {
                PhonebookRecord record = new PhonebookRecord()
                {
                    RecordId = rowNumber++,
                    //Company = (string)row[AssignedNameColumnName],
                    //Number = (string)row[AssignedNumberColumnName]
                    Company = (string)row[AssignComboColumns[_assignedNameColumnIndex]],
                    Number = (string)row[AssignComboColumns[_assignedNumberColumnIndex]]
                };
                records.Add(record);
            }

            try
            {
                response = service.ImportContacts(records.ToArray());
                responseMessageSB.AppendFormat("Počet úspěšně importovaných záznamů: {0}",
                    response.SuccessRecordsCount);
            }
            catch (FaultException<ImportRecordsResponseError> ex)
            {

                responseMessageSB.AppendFormat
                    ("Počet úspěšně importovaných záznamů: {0}\n\n", ex.Detail.SuccessRecordsCount);
                responseMessageSB.AppendFormat
                    ("Počet záznamů, které se nepodařilo importovat: {0}\n\n", ex.Detail.ErrorRecordsCount);
                responseMessageSB.Append("Seznam chyb v importním souboru::\n");
                foreach (ImportRecordResponseError importError in ex.Detail.ImportErrors)
                {
                    responseMessageSB.AppendFormat(
                        "Řádek:{0}\t\tSloupec:{1}\t\tChyba:{2}\n",
                        importError.RecordId.Value.ToString("00"),
                        importError.ColumnId.Value.ToString("00"),
                        importError.ErrorType.ToString());
                }
            }
            catch (CommunicationException ex)
            {
                MessageBox.Show("Komunikace se službou se nezdařila! \n\n" + ex.Message, "Chyba komunikace",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba programu! \n\n" + ex.Message, "Chyba programu",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                ResponseMessage = responseMessageSB.ToString();
            }
        }

        #endregion

        #region Commands
        private bool AlwaysTrue() { return true; }
        private bool AlwaysFalse() { return false; }

        public ICommand OpenCSVFileCmd { get { return new RelayCommand(OpenCSVFileAndReadData, AlwaysTrue); } }
        public ICommand ImportDataCmd { get { return new RelayCommand(ImportDataAndSaveCfg); } }

        //public RelayCommand<object> SampleCmdWithArgument { get { return new RelayCommand<object>(OnSampleCmdWithArgument); } }
        //private void OnSampleCmdWithArgument(object obj)
        //{
        //    // TODO
        //}



        private void OnExitApp()
        {
            System.Windows.Application.Current.MainWindow.Close();
        }
        #endregion

        #region Events


        #endregion
    }


}
